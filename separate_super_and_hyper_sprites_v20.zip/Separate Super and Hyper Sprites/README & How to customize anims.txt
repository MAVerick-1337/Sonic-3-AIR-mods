=============================
      Table of Contents
=============================

LINE             SECTION
002..............Table of Contents
018..............Compatibility Information
041..............Explanation of Settings
092..............Customizing Animations
186..............Credit and Permissions
211..............List of Identifiers
244..............Hex Guide

For the best viewing experience, view this document with line numbers
enabled, a monospace font, and tab length 4.

=====================================
      Compatibility information
=====================================

As of ver. 2.0, this mod uses Standalone.getModdedAnimationSpriteKey()
to change its sprites. However, due to some restrictions in how this
function works, some parts of the mod may cause compatibility issues due
to certain workarounds. The following features require such workarounds
and can be disabled in the mod's settings in case you experience any
issues:

	Super/Hyper Sonic's peelout animation (only with classic rotation)
	Base/Super/Hyper Knuckles' Glide animations
	Base/Super/Hyper Knuckles' Glide turn animations

The following features require workarounds and cannot be disabled:

	Super/Hyper Tails' Tails (necessary for the mod to function)

Note that even with these settings disabled, Separate Super/Hyper
Sprites is not guaranteed to be compatible with any other script-based
animation editing mods.

===================================
      Explanation of Settings
===================================

This section will explain how some of the settings in this mod work.

Each form for each character can be disabled (excluding Super Sonic,
since that's vanilla). Note that disabling a form will ignore all
settings for that form (e.g. if Hyper Tails' sprites are disabled, it'll
ignore the setting for Hyper Tails' standing sprites, even if they
exist).

Additionally, the Hyper standing animations, Super/Hyper Knuckles' glide
animations, Super/Hyper Knuckles' glide turn animations, and Super/Hyper
Sonic's peelout animation all have an additional option to enable them
only when sprites are found. When set to "Enabled", these will fall back
to the previous form's sprites. Setting them to "Only if sprites found"
will disable the custom animation instead of falling back (e.g. Super
Sonic would use his normal run sprites instead of base Sonic's peelout).
By default, only Super Sonic should have this set to "Only when sprites
found".

With version 2.0, the debug settings have been overhauled to make them
more useful. The old style of using System.writeDisplayLine() is still
available, however a more capable and easier to read option has been
added. To use it, enable dev mode (see the Sonic 3 AIR manuals) and
change the "Debug Output" option to "debugLog()". Additionally, multiple
levels of debug information are available:

	"Sprite Key" - Outputs the modified sprite key, if any
	"Key & State" - Outputs the sprite key, as well as the character's
			current state, sprite, and frame. Also outputs the current
			Separate Sprites state and any character specific states,
			like Knuckles' gliding

The following debug levels are only supported with "debugLog()" output:

	"Key, State, & Errors" - Outputs same info as above, but also
			includes any "Sprite not found" errors. Also indicates if
			fallback was enabled.
	"Verbose" - Outputs same information as above, as well as some
			miscellaneous info. This includes stuff like when the
			workaround is being done, etc. The debug string may become
			too long with this option (even for debugLog()), so consider
			using the other levels instead (please report this as a bug
			if it happens).

An option for debugging Tails' Tails is also included. If both options
are set to System.writeDisplayLine() mode, Tails' Tails will overwrite
normal debug info.

==================================
      Customizing Animations
==================================

As of version 1.2.0, this mod now supports separate standing animations
for each character. Additionally, as of v2.0, this also includes
Knuckles' gliding animation, as well as his glide turn animations. The
length of these animations depends on the number of sprites defined in
the JSON files. Template JSON and spritesheet files can be found in the
"Separate Super and Hyper Standing Sprites" and the "Separate Super and
Hyper Template Sprites" mods that were included in the download.

For these animations, Separate Sprites will automatically count the
number of frames, counting up from 0 until it reaches the last frame of
the animation. This means that in order for the game to recognize all
the frames of your animation, they must count up in order (in
hexadecimal) without skipping any numbers. The identifiers should follow
this general format:

	character_supertails_standing_0x??

Where "??" is the number of the frame in hexadecimal (a short guide on
hexadecimal numbers is included at the end of this document).

For example:
	character_supertails_standing_0x00
	character_supertails_standing_0x01
	character_supertails_standing_0x02
	...
	character_supertails_standing_0x09
	character_supertails_standing_0x0a
	character_supertails_standing_0x0b

Assuming that it kept counting from 3-8, the game would recognize 12
frames for the animation (in this example, the highest frame number
would be 0x0b).

All characters' standing animations and Knuckles' left and right gliding
animations can have a maximum of 255 frames. Knuckles' left and right
glide turn animations can have a maximum of 64 frames. The identifiers
for these animations are included in the "List of Identifiers" section.

The speed of each standing animation and Knuckles' glide animations can
be changed in the mod's settings. The following speeds are available,
along with their corresponding setting:

	0x0e: Slowest
	0x0c: Slower
	0x0a: Slow
	0x08: Normal/Vanilla
	0x06: Fast
	0x04: Faster
	0x02: Fastest

The speeds indicate the number of frames before it switches to the next
frame in the animation. e.g. "Slowest" will wait 14 frames before
switching, while "Fastest" will only wait 2 frames.

As of version 2.0, the standing animations will start from frame 0 and
play until they reach the last frame, rather than starting somewhere in
middle of the animation. After the last frame of the animation, it will
loop back to frame 0. Knuckles' glide animations also work the same way.

Unlike the standing or glide animations, Knuckles' glide turn animations
do not have a settable speed value. The frames are instead divided
evenly throughout the animation. For example, including 5 frames for
Knuckles' glide turn animation would result in it changing sprites every
12/13 frames or so. The maximum number of frames supported is 64 (0x40),
and an example of this is included in the template sprites mod.

Additionally, both Knuckles' glide and glide turn animations have
separate left and right variants. If you want them to be the same, you
can simply mirror the sprites for the gliding animations, and define the
glide turn right animation to be the same as the glide turn left
animation in reverse. For example, in a 5 frame animation, your

	character_knuckles_glide_turn_left_0x04

would become your

	character_knuckles_glide_turn_right_0x00

and so on, keeping the same "Rect" and "Center" values. Additionally,
Separate Sprites will not switch to the opposite turning animation
until Knuckles has fully stopped turning (e.g. turning halfway left and
then turning back right would play the left turn animation in reverse).

All of Separate Sprites' custom animations can be disabled in the mod's
settings, so making sprites for the vanilla animations is highly
recommended.

RECOMMENDED: Use an advanced text editor (like Geany or Notepad++) to
edit your .JSON files.

==================================
      Credit and Permissions
==================================

This mod is designed to allow people to mod Super/Hyper forms for all
characters using sprite modding. Because of this, you are free to edit
any of the template files and include them in your mods without credit
(though it is appreciated).

YOU MAY NOT INCLUDE THE SCRIPTS IN YOUR MOD. Instead, tell people to
download this mod and give it a lower priority than your mod. You can
do this in the "Requirements" section on Gamebanana. Also, the newest
test builds of Sonic 3 AIR (as of writing) include features that allow
you to have a recommended mod order and dependencies in your mod.json,
so consider using these features if it wouldn't break on the latest
Stable release of AIR.

Feel free to look through the scripts as a reference for making your own
mods. You do not need permission to make script mods for Separate Super
and Hyper Sprites (just don't take any functions without modifying
them). Additionally, some functions were specifically designed with
modding in mind (mostly in regard to 2P support), and you are encouraged
to use them to make your mods compatible with this one.


===============================
      LIST OF IDENTIFIERS
===============================

Following is a list of valid identifiers, without the frame number at
the end. Please see the above sections for information on what they're
for.

	character_supersonic_standing
	character_hypersonic_standing

	character_supertails_standing
	character_hypertails_standing

	character_superknuckles_standing
	character_hyperknuckles_standing

	character_knuckles_glide_left
	character_superknuckles_glide_left
	character_hyperknuckles_glide_left

	character_knuckles_glide_right
	character_superknuckles_glide_right
	character_hyperknuckles_glide_right

	character_knuckles_glide_turn_left
	character_superknuckles_glide_turn_left
	character_hyperknuckles_glide_turn_left

	character_knuckles_glide_turn_right
	character_superknuckles_glide_turn_right
	character_hyperknuckles_glide_turn_right

=====================
      HEX GUIDE
=====================

This is meant to be a quick and dirty guide to help people who don't
know how hexadecimal numbers work. This is not meant to be an extensive
guide, but rather a tool to make this mod accessible to more people.

0x - Prefix that means a number's in Hexadecimal
0x00 = 00
0x01 = 01
0x02 = 02
...
0x09 = 09
0x0a = 10
0x0b = 11
0x0c = 12
0x0d = 13
0x0e = 14
0x0f = 15
0x10 = 16
0x11 = 17
...
0x1a = 26
0x1b = 27
0x1c = 28
0x1d = 29
0x1e = 30
0x1f = 31
0x20 = 32
...and so on.

Hexadecimal works like decimal counting, except it includes additional
digits for 10-15 (shown above). Each digit represents a grouping of 16
instead of a grouping of 10. For example, the number 0x3c would be
broken down into 3*16 + 12*1 = 60. For more information, Google
hexadecimal numbers.
