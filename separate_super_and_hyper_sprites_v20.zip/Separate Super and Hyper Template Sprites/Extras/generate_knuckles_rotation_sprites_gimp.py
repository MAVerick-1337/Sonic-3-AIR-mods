# Script by DaKingofCheckerz
# imports
import math

# Params
new_layer_width = 60
new_layer_height = 60
layer_width_offset = 4
layer_height_offset = 4
step_size = 2	# Angle to rotate each frame by

# Calculated values
total_width = new_layer_width + layer_width_offset
total_height = new_layer_height + layer_height_offset
new_center_x = new_layer_width / 2
new_center_y = new_layer_height / 2

# Disable interpolation
Gimp.context_set_interpolation(0)

# (Re)set i
i = step_size
while i < 0xff:
	layer = Gimp.Layer.copy(main_layer)
	image.insert_layer(layer, None, -1)
	angle = (i / 0xff) * math.tau * -1
	layer.transform_rotate(angle, False, 24, 24)
	width = layer.get_width()
	height = layer.get_height()
	off_x = new_center_x - math.floor(0.5 + width / 2)
	off_y = new_center_y - math.floor(0.5 + height / 2)
	layer.resize(new_layer_width, new_layer_height, off_x, off_y)
	layer_number = i / step_size
	x_offset = (layer_number % 16) * total_width
	y_offset = math.floor(layer_number / 16) * total_height
	layer.set_offsets(x_offset, y_offset)
	i += step_size

