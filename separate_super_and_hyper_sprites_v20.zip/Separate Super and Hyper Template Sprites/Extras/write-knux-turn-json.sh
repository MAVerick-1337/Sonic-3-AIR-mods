#!/bin/bash
# Script by DaKingofCheckerz
NEW_LAYER_WIDTH=60
NEW_LAYER_HEIGHT=60
LAYER_WIDTH_OFFSET=4
LAYER_HEIGHT_OFFSET=4

TOTAL_WIDTH=$((NEW_LAYER_WIDTH + LAYER_WIDTH_OFFSET))
TOTAL_HEIGHT=$((NEW_LAYER_HEIGHT + LAYER_HEIGHT_OFFSET))
NEW_CENTER_X=$((NEW_LAYER_WIDTH / 2))
NEW_CENTER_Y=$((NEW_LAYER_HEIGHT / 2))

if [[ -z $1 ]] ; then
	>&2 echo -e "You must enter a file name!\n"
	exit
elif [[ -z $2 ]] ; then
	>&2 echo -e "You must enter a bmp name!\n"
	exit
fi

FILE=$1
BMP_NAME=$2

FORMAT="\t\"character_knuckles_glide_turn_%s_0x%02x\": { \"File\": \"$BMP_NAME\", \"Rect\" : \"%d, %d, $NEW_LAYER_WIDTH, $NEW_LAYER_HEIGHT\", \"Center\" : \"$NEW_CENTER_X, $NEW_CENTER_Y\" },\n"

# Params: <direction> <first frame> <# frames>
function output_json {
	for ((i = $2 ; i < $3 ; i++)) ; do
		frame=$((i + $4))
		x=$(((frame % 16) * TOTAL_WIDTH))
		y=$(((frame / 16) * TOTAL_HEIGHT))

		printf "$FORMAT" $1 $i $x $y >> "./$FILE"
	done
}

# Clear file
echo -ne '{\n' > "$FILE"
output_json "left" 0x00 0x40 0x00
output_json "right" 0x00 0x40 0x40

# Remove trailing comma and close braces
sed -i '$ s/.$//' $FILE
echo -e "}" >> $FILE
